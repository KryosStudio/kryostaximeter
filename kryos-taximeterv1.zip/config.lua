Config = {}

Config.TaxiModels = {
    `taxi`,
    `cabby`
}

Config.CursorKey = 'U' -- Key to open cursor mode

Config.Meter = {
    UseMPH = false,       -- Use MPH (Miles) instead of KM
    DayTariff = 5.0,      -- Day opening fee
    DayRatePerKm = 3.0,   -- Day rate per km/mile
    NightTariff = 8.0,    -- Night opening fee
    NightRatePerKm = 5.0, -- Night rate per km/mile
    NightStartHour = 20,  -- Night tariff start hour (20:00)
    NightEndHour = 6      -- Night tariff end hour (06:00)
}

Config.Locale = {
    currency_prefix = '',
    currency_suffix = ' $',
    rate_label = 'RATE',
    day_rate = 'DAY',
    night_rate = 'NIGHT',
    hired = 'HIRED',
    extra = 'EXTRA',
    cursor_hint = 'Cursor Mode',
    unit_km = 'KM',
    unit_mi = 'MI'
}
