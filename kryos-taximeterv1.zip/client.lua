local QBCore = exports['qb-core']:GetCoreObject()
local meterActive = false
local meterUIVisible = false
local fare = 0.0
local distance = 0.0
local tariff = Config.Meter.DayTariff
local lastPos = nil
local isDriver = false
local cursorActive = false
local currentRateType = "SABAH"
local distDivisor = Config.Meter.UseMPH and 1609.34 or 1000.0

local currentTaxiVehicle = 0
local vehicleData = {}

local function getRateTypeAndRates()
    local hour = GetClockHours()
    local isNight = false
    if Config.Meter.NightStartHour > Config.Meter.NightEndHour then
        isNight = (hour >= Config.Meter.NightStartHour or hour < Config.Meter.NightEndHour)
    else
        isNight = (hour >= Config.Meter.NightStartHour and hour < Config.Meter.NightEndHour)
    end
    
    if isNight then
        return Config.Locale.night_rate, Config.Meter.NightTariff, Config.Meter.NightRatePerKm
    else
        return Config.Locale.day_rate, Config.Meter.DayTariff, Config.Meter.DayRatePerKm
    end
end

local function isTaxiVehicle(vehicle)
    if vehicle == 0 then return false end
    local model = GetEntityModel(vehicle)
    for _, taxiModel in ipairs(Config.TaxiModels) do
        if model == taxiModel then return true end
    end
    return false
end

local function sendConfigToUI(isDrv)
    SendNUIMessage({
        action = 'setup',
        locale = Config.Locale,
        isDriver = isDrv,
        cursorKey = Config.CursorKey or 'U',
        distanceUnit = Config.Meter.UseMPH and Config.Locale.unit_mi or Config.Locale.unit_km
    })
end

function startMeter()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 then return end
    
    local rateType, openTariff, _ = getRateTypeAndRates()
    currentRateType = rateType
    
    if fare == 0.0 then
        tariff = openTariff
        fare = tariff
        distance = 0.0
    end
    
    meterActive = true
    lastPos = GetEntityCoords(ped)
    SendNUIMessage({ action = 'show' })
    local vehNetId = VehToNet(vehicle)
    
    vehicleData[vehNetId] = {
        fare = fare,
        distance = distance,
        tariff = tariff,
        active = meterActive,
        rateType = currentRateType
    }
    
    TriggerServerEvent('kryos-taximeterv1:server:syncMeter', vehNetId, string.format('%.2f', fare), string.format('%.2f', distance / distDivisor), string.format('%.2f', tariff), true, currentRateType)
end

function stopMeter()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    meterActive = false
    lastPos = nil
    -- Keep UI visible, just stop calculating
    if vehicle ~= 0 then
        local vehNetId = VehToNet(vehicle)
        
        vehicleData[vehNetId] = {
            fare = fare,
            distance = distance,
            tariff = tariff,
            active = meterActive,
            rateType = currentRateType
        }
        
        TriggerServerEvent('kryos-taximeterv1:server:syncMeter', vehNetId, string.format('%.2f', fare), string.format('%.2f', distance / distDivisor), string.format('%.2f', tariff), false, currentRateType)
    end
    SendNUIMessage({
        action = 'update',
        active = false,
        fare = string.format('%.2f', fare),
        distance = string.format('%.2f', distance / distDivisor),
        tariff = string.format('%.2f', tariff)
    })
end

function resetMeter()
    meterActive = false
    fare = 0.0
    distance = 0.0
    lastPos = nil
    
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle ~= 0 then
        local vehNetId = VehToNet(vehicle)
        
        vehicleData[vehNetId] = {
            fare = 0.0,
            distance = 0.0,
            tariff = tariff,
            active = false,
            rateType = currentRateType
        }
        
        TriggerServerEvent('kryos-taximeterv1:server:syncMeter', vehNetId, '0.00', '0.00', string.format('%.2f', tariff), false, currentRateType)
    end

    SendNUIMessage({
        action = 'update',
        active = false,
        fare = '0.00',
        distance = '0.00',
        tariff = string.format('%.2f', tariff)
    })
end

CreateThread(function()
    while true do
        Wait(500)
        local ped = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(ped, false)
        
        -- Hide if paused
        if IsPauseMenuActive() and meterUIVisible then
            meterUIVisible = false
            SendNUIMessage({ action = 'hide' })
            if cursorActive then
                cursorActive = false
                SetNuiFocus(false, false)
            end
        end

        if vehicle ~= 0 and isTaxiVehicle(vehicle) then
            if currentTaxiVehicle ~= vehicle then
                currentTaxiVehicle = vehicle
                local vehNetId = VehToNet(vehicle)
                local vData = vehicleData[vehNetId]
                if vData then
                    fare = vData.fare
                    distance = vData.distance
                    tariff = vData.tariff
                    meterActive = vData.active
                    if vData.rateType then currentRateType = vData.rateType end
                else
                    fare = 0.0
                    distance = 0.0
                    meterActive = false
                end
            end
            
            local isSeatDriver = (GetPedInVehicleSeat(vehicle, -1) == ped)
            
            if not meterUIVisible then
                isDriver = isSeatDriver
                meterUIVisible = true
                sendConfigToUI(isDriver)
                SendNUIMessage({ action = 'show' })
                
                if isDriver then
                    TriggerServerEvent('kryos-taximeterv1:server:openMeter', VehToNet(vehicle))
                else
                    local rateType, _, _ = getRateTypeAndRates()
                    SendNUIMessage({
                        action = 'update',
                        active = false,
                        fare = string.format('%.2f', fare),
                        distance = string.format('%.2f', distance / distDivisor),
                        tariff = string.format('%.2f', tariff),
                        rateType = rateType
                    })
                end
            else
                if isDriver ~= isSeatDriver then
                    isDriver = isSeatDriver
                    sendConfigToUI(isDriver)
                    
                    if isDriver then
                        TriggerServerEvent('kryos-taximeterv1:server:openMeter', VehToNet(vehicle))
                    else
                        meterActive = false
                        lastPos = nil
                        if cursorActive then
                            cursorActive = false
                            SetNuiFocus(false, false)
                        end
                        
                        local rateType, _, _ = getRateTypeAndRates()
                        SendNUIMessage({
                            action = 'update',
                            active = false,
                            fare = string.format('%.2f', fare),
                            distance = string.format('%.2f', distance / distDivisor),
                            tariff = string.format('%.2f', tariff),
                            rateType = rateType
                        })
                    end
                end
            end
            
            if isDriver then
                if meterActive then
                    local rateType, _, currentRatePerKm = getRateTypeAndRates()
                    currentRateType = rateType
                    
                    local currentPos = GetEntityCoords(ped)
                    if lastPos then
                        local dist = #(currentPos - lastPos)
                        distance = distance + dist
                        fare = fare + (dist / distDivisor) * currentRatePerKm
                    end
                    lastPos = currentPos
                end
                
                -- Always update driver NUI, active or not
                local fareStr = string.format('%.2f', fare)
                local distStr = string.format('%.2f', distance / distDivisor)
                local tariffStr = string.format('%.2f', tariff)
                
                SendNUIMessage({
                    action = 'update',
                    active = meterActive,
                    fare = fareStr,
                    distance = distStr,
                    tariff = tariffStr,
                    rateType = currentRateType
                })
                
                local vehNetId = VehToNet(vehicle)
                
                vehicleData[vehNetId] = {
                    fare = fare,
                    distance = distance,
                    tariff = tariff,
                    active = meterActive,
                    rateType = currentRateType
                }
                
                TriggerServerEvent('kryos-taximeterv1:server:syncMeter', vehNetId, fareStr, distStr, tariffStr, meterActive, currentRateType)
            end
        else
            if meterUIVisible then
                meterUIVisible = false
                meterActive = false
                lastPos = nil
                
                if cursorActive then
                    cursorActive = false
                    SetNuiFocus(false, false)
                end
                SendNUIMessage({ action = 'hide' })
                
                if isDriver and vehicle ~= 0 then
                    TriggerServerEvent('kryos-taximeterv1:server:closeMeter', VehToNet(vehicle))
                end
                isDriver = false
            end
        end
    end
end)

RegisterNetEvent('kryos-taximeterv1:client:syncMeter', function(vehNetId, fareStr, distStr, tariffStr, active, rateType, driverSrc)
    vehicleData[vehNetId] = {
        fare = tonumber(fareStr) or 0.0,
        distance = (tonumber(distStr) or 0.0) * distDivisor,
        tariff = tonumber(tariffStr) or 0.0,
        active = active,
        rateType = rateType
    }

    if driverSrc == GetPlayerServerId(PlayerId()) then return end
    
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle ~= 0 and NetworkGetEntityIsNetworked(vehicle) and VehToNet(vehicle) == vehNetId then
        if not meterUIVisible then
            meterUIVisible = true
            isDriver = false
            sendConfigToUI(false)
            SendNUIMessage({ action = 'show' })
        end
        SendNUIMessage({
            action = 'update',
            active = active,
            fare = fareStr,
            distance = distStr,
            tariff = tariffStr,
            rateType = rateType
        })
    end
end)

RegisterNetEvent('kryos-taximeterv1:client:openMeter', function(vehNetId, driverSrc)
    if driverSrc == GetPlayerServerId(PlayerId()) then return end
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle ~= 0 and NetworkGetEntityIsNetworked(vehicle) and VehToNet(vehicle) == vehNetId then
        meterUIVisible = true
        isDriver = false
        sendConfigToUI(false)
        SendNUIMessage({ action = 'show' })
    end
end)

RegisterNetEvent('kryos-taximeterv1:client:closeMeter', function(vehNetId, driverSrc)
    if driverSrc == GetPlayerServerId(PlayerId()) then return end
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    -- closeMeter removed logic so passengers keep UI visible
    -- Do nothing on closeMeter from driver so passenger sees last fare
end)

RegisterCommand('+toggletaxicursor', function()
    if meterUIVisible and isDriver and not cursorActive then
        cursorActive = true
        SetNuiFocus(true, true)
        SendNUIMessage({ action = 'cursor', state = true })
    end
end, false)
RegisterKeyMapping('+toggletaxicursor', 'Taksimetre Cursor (Aç)', 'keyboard', Config.CursorKey or 'U')

RegisterNUICallback('closeCursor', function(_, cb)
    cursorActive = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'cursor', state = false })
    if cb then cb('ok') end
end)

RegisterNUICallback('startMeter', function(_, cb)
    if isDriver then startMeter() end
    cb('ok')
end)

RegisterNUICallback('stopMeter', function(_, cb)
    if isDriver then stopMeter() end
    cb('ok')
end)

RegisterNUICallback('resetMeter', function(_, cb)
    if isDriver then resetMeter() end
    cb('ok')
end)
