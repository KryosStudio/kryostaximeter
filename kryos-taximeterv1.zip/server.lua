local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('kryos-taximeterv1:server:syncMeter', function(vehNetId, fare, distance, tariff, active, rateType)
    TriggerClientEvent('kryos-taximeterv1:client:syncMeter', -1, vehNetId, fare, distance, tariff, active, rateType, source)
end)

RegisterNetEvent('kryos-taximeterv1:server:openMeter', function(vehNetId)
    TriggerClientEvent('kryos-taximeterv1:client:openMeter', -1, vehNetId, source)
end)

RegisterNetEvent('kryos-taximeterv1:server:closeMeter', function(vehNetId)
    TriggerClientEvent('kryos-taximeterv1:client:closeMeter', -1, vehNetId, source)
end)
