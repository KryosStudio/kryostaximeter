fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Kryos Studio'
description 'Kryos Taximeter System V1'
version '1.0.0'

shared_scripts {
    '@qb-core/shared/locale.lua',
    'config.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css',
    'ui/script.js'
}
