const container = document.getElementById('taximeter-container');
const meterStatus = document.getElementById('status-hired');
const farePrefix = document.getElementById('fare-prefix');
const fareValue = document.getElementById('fare-value');
const fareSuffix = document.getElementById('fare-suffix');
const tariffValue = document.getElementById('tariff-value');
const distanceValue = document.getElementById('distance-value');
const btnStart = document.getElementById('btn-start');
const btnStop = document.getElementById('btn-stop');
const btnReset = document.getElementById('btn-reset');
const controls = document.getElementById('meter-controls');
const cursorHint = document.getElementById('cursor-hint');
const cursorKeyEl = document.getElementById('cursor-key');

let currentLocale = null;

function meterAction(action) {
    fetch('https://kryos-taximeterv1/' + action + 'Meter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}'
    }).catch(e => console.log(e));
}

window.addEventListener('message', function(event) {
    const data = event.data;

    if (data.action === 'setup') {
        currentLocale = data.locale;
        
        if (currentLocale) {
            farePrefix.textContent = currentLocale.currency_prefix || '';
            const extraPrefix = document.getElementById('extra-prefix');
            if (extraPrefix) extraPrefix.textContent = currentLocale.currency_prefix || '';
            if (currentLocale.currency_suffix) {
                fareSuffix.textContent = currentLocale.currency_suffix;
                fareSuffix.style.display = 'inline';
            } else {
                fareSuffix.style.display = 'none';
            }
            if (currentLocale.rate_label) {
                const rl = document.getElementById('rate-label');
                if (rl) rl.textContent = currentLocale.rate_label;
            }
            if (currentLocale.hired) {
                const sh = document.getElementById('status-hired');
                if (sh) sh.textContent = currentLocale.hired;
            }
            if (currentLocale.extra) {
                const ex = document.getElementById('extra-label');
                if (ex) ex.textContent = currentLocale.extra;
            }
            if (currentLocale.cursor_hint) {
                const ch = document.getElementById('cursor-text');
                if (ch) ch.textContent = currentLocale.cursor_hint;
            }
        }
        
        if (data.cursorKey) {
            cursorKeyEl.textContent = data.cursorKey;
        }

        if (data.distanceUnit) {
            const distUnitEl = document.getElementById('distance-unit');
            if (distUnitEl) distUnitEl.textContent = data.distanceUnit;
        }

        if (data.isDriver) {
            controls.classList.remove('hidden');
            cursorHint.classList.remove('hidden');
        } else {
            controls.classList.add('hidden');
            cursorHint.classList.add('hidden');
        }

        if (data.tariff !== undefined) {
            tariffValue.textContent = data.tariff;
        }
    }

    if (data.action === 'show') {
        container.classList.remove('hidden');
    }

    if (data.action === 'hide') {
        container.classList.add('hidden');
    }

    if (data.action === 'cursor') {
        if (data.state) {
            cursorHint.classList.add('active');
        } else {
            cursorHint.classList.remove('active');
        }
    }

    if (data.action === 'update') {
        if (data.active) {
            meterStatus.classList.add('active');
        } else {
            meterStatus.classList.remove('active');
        }

        if (data.fare !== undefined) {
            fareValue.textContent = data.fare;
        }
        if (data.distance !== undefined) {
            distanceValue.textContent = data.distance;
        }
        if (data.tariff !== undefined) {
            tariffValue.textContent = data.tariff;
        }
        if (data.rateType !== undefined) {
            const rateValueEl = document.getElementById('rate-value');
            if (rateValueEl) rateValueEl.textContent = data.rateType;
        }
    }
});

window.addEventListener('keydown', function(event) {
    const dynamicKey = cursorKeyEl ? cursorKeyEl.textContent.toLowerCase() : 'u';
    
    if (event.key.toLowerCase() === dynamicKey || event.key === 'Escape') {
        fetch('https://kryos-taximeterv1/closeCursor', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: '{}'
        }).catch(e => console.log(e));
    }
});
