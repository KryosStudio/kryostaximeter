const container = document.getElementById('taximeter-container');
const meterTitle = document.getElementById('meter-title');
const meterStatus = document.getElementById('meter-status');
const farePrefix = document.getElementById('fare-prefix');
const fareValue = document.getElementById('fare-value');
const fareSuffix = document.getElementById('fare-suffix');
const tariffLabel = document.getElementById('tariff-label');
const tariffValue = document.getElementById('tariff-value');
const distanceLabel = document.getElementById('distance-label');
const distanceValue = document.getElementById('distance-value');
const perkmValue = document.getElementById('perkm-value');
const btnStart = document.getElementById('btn-start');
const btnStop = document.getElementById('btn-stop');
const btnReset = document.getElementById('btn-reset');
const controls = document.getElementById('meter-controls');

let currentLocale = null;

function meterAction(action) {
    fetch('https://kryos-taximeterv1/' + action + 'Meter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}'
    }).catch(e => console.log(e));
}

function applyTheme(theme) {
    if(!theme) return;
    const root = document.documentElement;
    if(theme.PrimaryColor) root.style.setProperty('--primary-color', theme.PrimaryColor);
    if(theme.PrimaryColorTrans) root.style.setProperty('--primary-color-trans', theme.PrimaryColorTrans);
    if(theme.PrimaryColorGlow) root.style.setProperty('--primary-color-glow', theme.PrimaryColorGlow);
    if(theme.StatusActiveColor) root.style.setProperty('--status-active-color', theme.StatusActiveColor);
    if(theme.StatusActiveBg) root.style.setProperty('--status-active-bg', theme.StatusActiveBg);
}

window.addEventListener('message', function(event) {
    const data = event.data;

    if (data.action === 'setup') {
        applyTheme(data.theme);
        currentLocale = data.locale;
        
        if (currentLocale) {
            meterTitle.textContent = currentLocale.title || 'TAKSİMETRE';
            tariffLabel.textContent = currentLocale.tariff_label || 'Açılış Ücreti';
            distanceLabel.textContent = currentLocale.distance_label || 'Mesafe';
            farePrefix.textContent = currentLocale.currency_prefix || '';
            fareSuffix.textContent = currentLocale.currency_suffix || ' $';
            btnStart.innerHTML = '<i class="fa-solid fa-play"></i> ' + (currentLocale.meter_start || 'BAŞLAT');
            btnStop.innerHTML = '<i class="fa-solid fa-stop"></i> ' + (currentLocale.meter_stop || 'DURDUR');
            btnReset.innerHTML = '<i class="fa-solid fa-arrows-rotate"></i> ' + (currentLocale.meter_reset || 'SIFIRLA');
        }
        
        if (data.isDriver) {
            controls.classList.remove('hidden');
        } else {
            controls.classList.add('hidden');
        }

        if (data.tariff !== undefined && currentLocale) {
            tariffValue.textContent = (currentLocale.currency_prefix || '') + data.tariff + (currentLocale.currency_suffix || ' $');
        }

        if (data.ratePerKm !== undefined && currentLocale) {
            perkmValue.textContent = data.ratePerKm + ' ' + (currentLocale.currency_prefix || '') + (currentLocale.currency_suffix || ' $') + ' ' + (currentLocale.per_km || 'km başına');
        }
    }

    if (data.action === 'show') {
        container.classList.remove('hidden');
    }

    if (data.action === 'hide') {
        container.classList.add('hidden');
    }

    if (data.action === 'update') {
        if (data.active) {
            meterStatus.textContent = currentLocale ? currentLocale.meter_on : 'AÇIK';
            meterStatus.classList.add('active');
        } else {
            meterStatus.textContent = currentLocale ? currentLocale.meter_off : 'KAPALI';
            meterStatus.classList.remove('active');
        }

        if (data.fare !== undefined) {
            fareValue.textContent = data.fare;
        }
        if (data.distance !== undefined && currentLocale) {
            distanceValue.textContent = data.distance + ' ' + (currentLocale.distance_unit || 'km');
        }
        if (data.tariff !== undefined && currentLocale) {
            tariffValue.textContent = (currentLocale.currency_prefix || '') + data.tariff + (currentLocale.currency_suffix || ' $');
        }
    }
});
